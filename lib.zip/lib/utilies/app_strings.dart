class AppStrings {

  static const String appName = 'Sarmad Task';
  static const String errorState = 'OOPs error occured';
  static const String emptyState = 'No posts found';
  static const String fnameSearch = 'search by fname';
  static const String mnameSearch = 'search by mname';
  static const String natSearch = 'search by nat';
  static const String searchByAll = 'search by all';




}
