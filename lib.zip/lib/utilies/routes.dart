import 'package:flutter/widgets.dart';

final Map<String, WidgetBuilder> routes = {
 // ShowMovieScreen.routeName: (context) => ShowMovieScreen(),
};
